package ci.oda.jury_pro.enumType;

public enum UserType {
    admin, jury
}
