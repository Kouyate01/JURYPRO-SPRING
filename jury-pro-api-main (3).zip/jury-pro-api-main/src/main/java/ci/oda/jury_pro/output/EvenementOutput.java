package ci.oda.jury_pro.output;

import java.sql.Date;

public interface EvenementOutput {
    public Integer getEvenementId();
    public Integer getNbreParticipant();
    public String getEvenementNom();
    public Date getEvenementDateDebut();
    public Date getEvenementDateFin();
    public boolean getEvenementType();
    public byte[] getEvenementImage();
}
