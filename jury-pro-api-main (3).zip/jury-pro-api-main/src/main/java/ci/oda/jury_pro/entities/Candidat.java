package ci.oda.jury_pro.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import ci.oda.jury_pro.enumType.CandidatType;



@Entity
@Table(name = "candidats")
public class Candidat {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer candidatId;
    private String candidatNom;
    private String candidatPrenoms = "";
    @Lob
    private byte[] candidatPhoto;
    private String candidatEmail;

    @Enumerated(EnumType.STRING)
    private CandidatType candidatType = CandidatType.PERSONNE;

    @ManyToOne
    private Evenement evenement;


    @ManyToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(referencedColumnName = "candidatId")
    @JsonBackReference
    private Candidat groupe;



    @OneToMany(mappedBy = "voteCandidat", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<Vote> votes;


    public Candidat getGroupe() {
        return this.groupe;
    }

    public void setGroupe(Candidat groupe) {
        this.groupe = groupe;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }


    public Candidat() {
    }

    public Candidat(Integer candidatId, Evenement evenement, Candidat groupe, String candidatNom, String candidatPrenoms, byte[] candidatPhoto, String candidatEmail, CandidatType candidatType) {
        this.candidatId = candidatId;
        this.evenement = evenement;
        this.groupe = groupe;
        this.candidatNom = candidatNom;
        this.candidatPrenoms = candidatPrenoms;
        this.candidatPhoto = candidatPhoto;
        this.candidatEmail = candidatEmail;
        this.candidatType = candidatType;
    }

    public Integer getCandidatId() {
        return this.candidatId;
    }

    public void setCandidatId(Integer candidatId) {
        this.candidatId = candidatId;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public String getCandidatNom() {
        return this.candidatNom;
    }

    public void setCandidatNom(String candidatNom) {
        this.candidatNom = candidatNom;
    }

    public String getCandidatPrenoms() {
        return this.candidatPrenoms;
    }

    public void setCandidatPrenoms(String candidatPrenoms) {
        this.candidatPrenoms = candidatPrenoms;
    }

    public byte[] getCandidatPhoto() {
        return this.candidatPhoto;
    }

    public void setCandidatPhoto(byte[] candidatPhoto) {
        this.candidatPhoto = candidatPhoto;
    }

    public String getCandidatEmail() {
        return this.candidatEmail;
    }

    public void setCandidatEmail(String candidatEmail) {
        this.candidatEmail = candidatEmail;
    }


    public CandidatType getCandidatType() {
        return this.candidatType;
    }

    public void setType(CandidatType CandidatType) {
        this.candidatType = CandidatType;
    }


}
