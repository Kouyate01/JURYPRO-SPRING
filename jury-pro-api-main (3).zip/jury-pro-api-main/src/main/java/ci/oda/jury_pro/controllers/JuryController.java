package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.entities.Jury;
import ci.oda.jury_pro.exceptions.EvenementNotFoundException;
import ci.oda.jury_pro.services.EvenementService;
import ci.oda.jury_pro.services.JuryService;


@RestController
@CrossOrigin
public class JuryController {
    @Autowired
    JuryService juryService;

    @Autowired
    EvenementService eventService;

    @GetMapping("/jury")
    public List<Jury> all() {
        return juryService.findAll();
    }

    @GetMapping("/jury/{id}")
    Jury one(@PathVariable Integer id) {
        return juryService.findById(id).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @GetMapping("/jury/evenement/{eventId}")
    List<Jury> findByEvenement(@PathVariable Integer eventId){
        return this.eventService.findById(eventId).map((Evenement evenement) -> {
            return juryService.findByEvenement(evenement);
        }).orElseThrow(() -> new EvenementNotFoundException(eventId));
    }

    @GetMapping("/jury/telephone/{telephone}")
    List<Jury> findByTelephone(@PathVariable String telephone){
        return juryService.findByTelephone(telephone);
    }

    @PostMapping("/jury")
    public Jury create(@RequestBody Jury newJury) {
        return juryService.createOrUpdate(newJury);
    }

    @PutMapping("/jury/{id}")
    public Jury update(@RequestBody Jury newJury, @PathVariable Integer id) {
        return juryService.findById(id).map((Jury jury) -> {
            newJury.setJuryId(id);
            return juryService.createOrUpdate(newJury);
        }).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @DeleteMapping("/jury/{id}")
    public Boolean delete(@PathVariable Integer id){
        return juryService.findById(id)
            .map((Jury jury) -> {
                return juryService.deleteById(jury);
            }).orElse(false);
    }
}
