package ci.oda.jury_pro.output;

public interface CandidatOutput {

    public Integer getCandidatId();

    public String getCandidatNom();

    public String getCandidatPrenoms();

    public byte[] getCandidatPhoto();

    public String getCandidatEmail();

    public String getCandidatType();

    public String getParticipant();

    public Double getObtain();

    public Double getPossiblePerJury();

    public Integer getNbreJury();

    public Integer getNbreVote();
}
