package ci.oda.jury_pro.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "votes")
public class Vote {

    // @PersistenceContext
    // EntityManager em;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer voteId;

    @ManyToOne
    private Jury voteJury;

    @ManyToOne
    private Candidat voteCandidat;

    private String voteCommentaire="";

    @OneToMany(mappedBy = "critereNotationVote", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<CritereNotation> notations = new ArrayList<>();



    public Vote() {
    }

    public Vote(Integer voteId, String voteCommentaire, Jury voteJury, Candidat voteCandidat) {
        this.voteId = voteId;
        this.voteCommentaire = voteCommentaire;
        this.voteJury = voteJury;
        this.voteCandidat = voteCandidat;
    }

    public Integer getVoteId() {
        return this.voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public String getVoteCommentaire() {
        return this.voteCommentaire;
    }

    public void setVoteCommentaire(String voteCommentaire) {
        this.voteCommentaire = voteCommentaire;
    }

    public Jury getVoteJury() {
        return this.voteJury;
    }

    public void setVoteJury(Jury voteJury) {
        this.voteJury = voteJury;
    }

    public Candidat getVoteCandidat() {
        return this.voteCandidat;
    }

    public void setVoteCandidat(Candidat voteCandidat) {
        this.voteCandidat = voteCandidat;
    }

    @Override
    public String toString() {
        return "{" +
            " voteId='" + getVoteId() + "'" +
            ", voteCommentaire='" + getVoteCommentaire() + "'" +
            ", voteJury='" + getVoteJury() + "'" +
            ", voteCandidat='" + getVoteCandidat() + "'" +
            "}";
    }


    public List<CritereNotation> getNotations() {
        return this.notations;
    }

    public void setNotations(List<CritereNotation> notations) {
        this.notations = notations;
    }

}
