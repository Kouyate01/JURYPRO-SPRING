package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ci.oda.jury_pro.entities.CritereNotation;
import ci.oda.jury_pro.entities.CritereNotationKey;
import ci.oda.jury_pro.entities.Vote;

public interface CritereNotationRepository extends JpaRepository<CritereNotation, CritereNotationKey> {
    // List<NotationOutput> findByCritereNotationVote(Vote critereNotationVote);

    List<CritereNotation> findByCritereNotationVote(Vote critereNotationVote);
}
