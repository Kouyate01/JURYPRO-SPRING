package ci.oda.jury_pro.entities;

import java.util.Objects;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CritereNotation {
    @EmbeddedId
    private CritereNotationKey critereNotationId;

    @ManyToOne
    @MapsId("voteId")
    @JoinColumn(name = "vote_id")
    @JsonIgnore
    private Vote critereNotationVote;

    @ManyToOne
    @MapsId("critereId")
    @JoinColumn(name = "critere_id")
    private Critere critereNotationCritere;

    private Double critereNotationNote;

    public CritereNotation() {
    }

    public CritereNotation(Vote critereNotationVote, Critere critereNotationCritere, Double critereNotationNote) {
        this.critereNotationId = new CritereNotationKey(critereNotationVote.getVoteId(), critereNotationCritere.getCritereId());
        this.critereNotationVote = critereNotationVote;
        this.critereNotationCritere = critereNotationCritere;
        this.critereNotationNote = critereNotationNote;
    }

    public CritereNotationKey getCritereNotationId() {
        return this.critereNotationId;
    }

    public void setCritereNotationId(CritereNotationKey critereNotationId) {
        this.critereNotationId = critereNotationId;
    }

    public Vote getCritereNotationVote() {
        return this.critereNotationVote;
    }

    public void setCritereNotationVote(Vote critereNotationVote) {
        this.critereNotationVote = critereNotationVote;
    }

    public Critere getCritereNotationCritere() {
        return this.critereNotationCritere;
    }

    public void setCritereNotationCritere(Critere critereNotationCritere) {
        this.critereNotationCritere = critereNotationCritere;
    }

    public Double getCritereNotationNote() {
        return this.critereNotationNote;
    }

    public void setCritereNotationNote(Double critereNotationNote) {
        this.critereNotationNote = critereNotationNote;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof CritereNotation)) {
            return false;
        }
        CritereNotation critereNotation = (CritereNotation) o;
        return Objects.equals(critereNotationId, critereNotation.critereNotationId) && Objects.equals(critereNotationVote, critereNotation.critereNotationVote) && Objects.equals(critereNotationCritere, critereNotation.critereNotationCritere) && Objects.equals(critereNotationNote, critereNotation.critereNotationNote);
    }

    @Override
    public int hashCode() {
        return Objects.hash(critereNotationId, critereNotationVote, critereNotationCritere, critereNotationNote);
    }

    @Override
    public String toString() {
        return "{" +
            " critereNotationId='" + getCritereNotationId() + "'" +
            ", critereNotationVote='" + getCritereNotationVote() + "'" +
            ", critereNotationCritere='" + getCritereNotationCritere() + "'" +
            ", critereNotationNote='" + getCritereNotationNote() + "'" +
            "}";
    }
    

}
