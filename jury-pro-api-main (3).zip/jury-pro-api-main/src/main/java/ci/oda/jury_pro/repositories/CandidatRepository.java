package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import ci.oda.jury_pro.output.CandidatOutput;
import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Evenement;

public interface CandidatRepository extends JpaRepository<Candidat, Integer>{
    @Query(value = "SELECT c FROM Candidat c WHERE groupe_candidat_id = ?1")
    List<Candidat> findChildren(Integer parentId);

    @Query(value = "SELECT ca.candidat_id as candidatId, ca.candidat_email as candidatEmail, ca.candidat_nom as candidatNom, ca.candidat_prenoms as candidatPrenoms, ca.candidat_type as candidatType, ca.candidat_photo as candidatPhoto, (SELECT count(*) FROM candidats as child WHERE child.groupe_candidat_id = ca.candidat_id) as participant,(SELECT COALESCE(SUM(criteres.critere_bareme), 0) FROM criteres WHERE criteres.evenement_evenement_id = ?1) as possiblePerJury,(SELECT COUNT(jurys.jury_id) FROM jurys WHERE jurys.evenement_evenement_id = ?1) as nbreJury, (SELECT COUNT(*) FROM votes WHERE ca.candidat_id = votes.vote_candidat_candidat_id) as nbreVote , (SELECT COALESCE(SUM(critere_notation.critere_notation_note), 0) FROM votes, critere_notation WHERE ca.candidat_id = votes.vote_candidat_candidat_id AND critere_notation.vote_id = votes.vote_id) as obtain FROM candidats as ca WHERE evenement_evenement_id = ?1 ORDER BY obtain DESC;", nativeQuery = true)
    List<CandidatOutput> findByEvenementWithParticipantCount(Integer eventId);


    List<Candidat> findByEvenement(Evenement evenement);
}
