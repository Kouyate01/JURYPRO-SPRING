package ci.oda.jury_pro.input;

import ci.oda.jury_pro.enumType.CandidatType;

public class CandidatInput {
    private Integer candidatId;
    private String candidatNom;
    private String candidatPrenoms = "";
    private String image64;
    private String candidatEmail;
    private CandidatType type = CandidatType.PERSONNE;
    private Integer evenementId;
    private Integer groupeId;


    public CandidatInput() {
    }

    public CandidatInput(Integer candidatId, String candidatNom, String candidatPrenoms, String image64, String candidatEmail, CandidatType type, Integer evenementId, Integer groupeId) {
        this.candidatId = candidatId;
        this.candidatNom = candidatNom;
        this.candidatPrenoms = candidatPrenoms;
        this.image64 = image64;
        this.candidatEmail = candidatEmail;
        this.type = type;
        this.evenementId = evenementId;
        this.groupeId = groupeId;
    }

    public Integer getCandidatId() {
        return this.candidatId;
    }

    public void setCandidatId(Integer candidatId) {
        this.candidatId = candidatId;
    }

    public String getCandidatNom() {
        return this.candidatNom;
    }

    public void setCandidatNom(String candidatNom) {
        this.candidatNom = candidatNom;
    }

    public String getCandidatPrenoms() {
        return this.candidatPrenoms;
    }

    public void setCandidatPrenoms(String candidatPrenoms) {
        this.candidatPrenoms = candidatPrenoms;
    }

    public String getImage64() {
        return this.image64;
    }

    public void setImage64(String image64) {
        this.image64 = image64;
    }

    public String getCandidatEmail() {
        return this.candidatEmail;
    }

    public void setCandidatEmail(String candidatEmail) {
        this.candidatEmail = candidatEmail;
    }

    public CandidatType getType() {
        return this.type;
    }

    public void setType(CandidatType type) {
        this.type = type;
    }

    public Integer getEvenementId() {
        return this.evenementId;
    }

    public void setEvenementId(Integer evenementId) {
        this.evenementId = evenementId;
    }

    public Integer getGroupeId() {
        return this.groupeId;
    }

    public void setGroupeId(Integer groupeId) {
        this.groupeId = groupeId;
    }

}
