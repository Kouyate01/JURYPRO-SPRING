package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ci.oda.jury_pro.output.CandidatOutput;
import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.exceptions.EvenementNotFoundException;
import ci.oda.jury_pro.input.CandidatInput;
import ci.oda.jury_pro.services.CandidatService;
import ci.oda.jury_pro.services.EvenementService;


@RestController
@CrossOrigin
public class CandidatController {
    @Autowired
    CandidatService candidatService;

    @Autowired
    EvenementService evenementService;

    @GetMapping("/candidat")
    public List<Candidat> all() {
        return candidatService.findAll();
    }

    @GetMapping("/candidat/{id}")
    Candidat one(@PathVariable Integer id) {
        return candidatService.findById(id).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @GetMapping("/candidat/evenement/{eventId}")
    List<Candidat> findByEvenement(@PathVariable Integer eventId){
        return this.evenementService.findById(eventId).map((Evenement event) -> {
            return candidatService.findByEvenement(event);
        }).orElseThrow(() -> new EvenementNotFoundException(eventId));
    }

    @GetMapping("/candidat/evenement/test/{eventId}")
    List<CandidatOutput> findByEvenementTest(@PathVariable Integer eventId){
        return this.evenementService.findById(eventId).map((Evenement event) -> {
            return candidatService.findByEvenementTest(eventId);
        }).orElseThrow(() -> new EvenementNotFoundException(eventId));
    }

    @GetMapping(value="/candidat/{id}/children")
    public List<Candidat> getChildren(@PathVariable Integer id) {
        return candidatService.findChildren(id);
    }
    

    @PostMapping("/candidat")
    public Candidat create(@RequestBody CandidatInput newCandidat){
        Candidat candidat = candidatService.createOrUpdate(newCandidat);
        // if(candidat.getEvenement() != null){
        //     Evenement even = evenementService.findById(candidat.getEvenement().getEvenementId()).orElse(candidat.getEvenement());
        //     candidat.setEvenement(even);
        // }
        return candidat;
    }

    @PutMapping("/candidat/{id}")
    public Candidat update(@RequestBody CandidatInput newCandidat, @PathVariable Integer id){
        return candidatService.findById(id)
            .map((Candidat candidat) -> {
                newCandidat.setCandidatId(id);
                return candidatService.createOrUpdate(newCandidat);
            })
            .orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @DeleteMapping("/candidat/{id}")
    public Boolean delete(@PathVariable Integer id){
        return candidatService.findById(id)
            .map((Candidat candidat) -> {
                return candidatService.deleteById(candidat);
            }).orElse(false);
    }
}
