package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ci.oda.jury_pro.entities.Critere;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.exceptions.EvenementNotFoundException;
import ci.oda.jury_pro.services.CritereService;
import ci.oda.jury_pro.services.EvenementService;

@RestController
@CrossOrigin
public class CritereController {
    @Autowired
    CritereService critereService;

    @Autowired
    EvenementService eventService;

    @GetMapping("/critere")
    public List<Critere> all() {
        return critereService.findAll();
    }

    @GetMapping("/critere/{id}")
    Critere one(@PathVariable Integer id) {
        return critereService.findById(id).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @GetMapping("/critere/evenement/{eventId}")
    List<Critere> findByEvenement(@PathVariable Integer eventId){
        return this.eventService.findById(eventId).map((Evenement event) -> {
            System.out.println(event.getEvenementId());
            return critereService.findByEvenement(event);
        }).orElseThrow(() -> new EvenementNotFoundException(eventId));
    }

    @PostMapping("/critere")
    public Critere create(@RequestBody Critere newCritere){
        System.out.println("EN cours...");
        Critere critere = critereService.createOrUpdate(newCritere);
        // if(candidat.getEvenement() != null){
        //     Evenement even = evenementService.findById(candidat.getEvenement().getEvenementId()).orElse(candidat.getEvenement());
        //     candidat.setEvenement(even);
        // }else if(candidat.getGroupe() != null){
        //     Groupe groupe = groupeService.findById(candidat.getGroupe().getGroupeId()).orElse(candidat.getGroupe());
        //     candidat.setGroupe(groupe);
        // }
        return critere;
    }

    @PutMapping("/critere/{id}")
    public Critere update(@RequestBody Critere newCritere, @PathVariable Integer id){
        return critereService.findById(id)
            .map((Critere critere) -> {
                newCritere.setCritereId(id);
                return critereService.createOrUpdate(newCritere);
            })
            .orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @DeleteMapping("/critere/{id}")
    public Boolean delete(@PathVariable Integer id){
        return critereService.findById(id)
            .map((Critere critere) -> {
                return critereService.deleteById(critere);
            }).orElse(false);
    }
}
