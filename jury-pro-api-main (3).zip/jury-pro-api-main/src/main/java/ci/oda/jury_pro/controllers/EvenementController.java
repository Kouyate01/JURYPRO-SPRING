package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ci.oda.jury_pro.output.EvenementOutput;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.exceptions.EvenementNotFoundException;
import ci.oda.jury_pro.input.EvenementInput;
import ci.oda.jury_pro.services.EvenementService;



@RestController
@CrossOrigin
public class EvenementController {
    @Autowired
    EvenementService evenementService;

    @GetMapping("/evenement")
    public List<Evenement> all() {
        System.out.println();
        return evenementService.findAll();
    }

    @GetMapping("/evenement/test")
    public List<EvenementOutput> allTest() {
        return evenementService.findAllTest();
    }

    @GetMapping("/evenement/{id}")
    Evenement one(@PathVariable Integer id) {
        return evenementService.findById(id).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @PostMapping("/evenement")
    public Evenement create(@RequestBody EvenementInput newEvenement) {
        return evenementService.createOrUpdate(newEvenement);
    }

    @PutMapping("/evenement/{id}")
    public Evenement update(@RequestBody EvenementInput newEvenement, @PathVariable Integer id) {
        return evenementService.findById(id).map((Evenement evenement) -> {
            newEvenement.setEvenementId(id);
            return evenementService.createOrUpdate(newEvenement);
        }).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @DeleteMapping("/evenement/{id}")
    public Boolean delete(@PathVariable Integer id){
        return evenementService.findById(id)
            .map((Evenement evenement) -> {
                return evenementService.deleteById(evenement);
            }).orElse(false);
    }

}
