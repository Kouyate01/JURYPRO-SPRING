package ci.oda.jury_pro.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.CritereNotation;
import ci.oda.jury_pro.entities.Vote;
import ci.oda.jury_pro.input.NotationInput;
import ci.oda.jury_pro.input.VoteInput;
import ci.oda.jury_pro.output.NotationOutput;
import ci.oda.jury_pro.output.VoteOutput;
import ci.oda.jury_pro.repositories.CritereNotationRepository;
import ci.oda.jury_pro.repositories.VoteRepository;

@Service
public class VoteService {
    @Autowired
    VoteRepository voteRepository;

    @Autowired
    CritereNotationRepository critereNotationRepository;
    

    public List<Vote> findAll() {
        return voteRepository.findAll();
    }

    public Optional<Vote> findById(Integer id) {
        Optional<Vote>  vote = voteRepository.findById(id);
        return vote;
    }

    public List<VoteOutput> findByCandidat(Candidat candidat){
        List<VoteOutput> data = new ArrayList<VoteOutput>();
        List<Vote> votes = voteRepository.findByVoteCandidat(candidat);
        for(Vote vote: votes){
            // List<NotationOutput> notations = new ArrayList<NotationOutput>();
            // String commentaire, Integer voteId, Jury jury, List<NotationOutput> notations
            data.add(new VoteOutput(
                vote.getVoteCommentaire(),
                vote.getVoteId(),
                vote.getVoteJury(),
                critereNotationRepository.findByCritereNotationVote(vote)
            ));
        }
        return data;
    }

    public Boolean createOrUpdate(VoteInput vote){
        Boolean result = false;
        try{
            Vote newVote = voteRepository.save(new Vote(vote.getVoteId(), vote.getVoteCommentaire(), vote.getVoteJury(), vote.getVoteCandidat()));
            for(NotationInput notation : vote.getVoteNotations()){
                CritereNotation notationCritere = critereNotationRepository.save(new CritereNotation(newVote, notation.getCritere(), ((notation.getNote()*notation.getBareme())/5.0)));
                newVote.getNotations().add(notationCritere);
            }
            voteRepository.save(newVote);
            result = true;
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return result;
    }


    public boolean deleteById(Vote vote){
        try{
            voteRepository.deleteById(vote.getVoteId());
            return true;
        }catch(IllegalArgumentException e){
            return false;
        }
    }
}
