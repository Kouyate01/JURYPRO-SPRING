package ci.oda.jury_pro.input;

import ci.oda.jury_pro.entities.Critere;
import ci.oda.jury_pro.entities.Vote;

public class NotationInput {
    private Vote vote;
    private Critere critere;
    private Double note;
    private Double bareme;


    public NotationInput() {
    }

    public NotationInput(Vote vote, Critere critere, Double note) {
        this.vote = vote;
        this.critere = critere;
        this.note = note;
    }

    public Vote getVote() {
        return this.vote;
    }

    public void setVote(Vote vote) {
        this.vote = vote;
    }

    public Critere getCritere() {
        return this.critere;
    }

    public void setCritere(Critere critere) {
        this.critere = critere;
    }

    public Double getNote() {
        return this.note;
    }

    public void setNote(Double note) {
        this.note = note;
    }


    public Double getBareme() {
        return this.bareme;
    }

    public void setBareme(Double bareme) {
        this.bareme = bareme;
    }


}
