package ci.oda.jury_pro.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.entities.Jury;
import ci.oda.jury_pro.repositories.JuryRepository;

@Service
public class JuryService {
    @Autowired
    JuryRepository juryRepository;

    public List<Jury> findAll() {
        return juryRepository.findAll();
    }

    public Optional<Jury> findById(Integer id) {
        Optional<Jury>  even = juryRepository.findById(id);
        return even;
    }

    public List<Jury> findByEvenement(Evenement event){
        return juryRepository.findByEvenement(event);
    }

    public List<Jury> findByTelephone(String telephone){
        return juryRepository.findByJuryTelephone(telephone);
    }

    public Jury createOrUpdate(Jury jury){
        return juryRepository.save(jury);
    }

    public boolean deleteById(Jury jury){
        try{
            juryRepository.deleteById(jury.getJuryId());
            return true;
        }catch(IllegalArgumentException e){
            return false;
        }
    }
}
