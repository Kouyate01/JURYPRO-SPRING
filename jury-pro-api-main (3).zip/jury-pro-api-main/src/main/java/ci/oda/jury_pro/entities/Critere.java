package ci.oda.jury_pro.entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "criteres")
public class Critere {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer critereId;
    private String critereLibelle;
    private Double critereBareme;
    
    @ManyToOne
    private Evenement evenement;

    @OneToMany(mappedBy = "critereNotationCritere", fetch=FetchType.LAZY)
    private List<CritereNotation> notations = new ArrayList<>();

    public Critere() {
    }

    public Critere(Integer critereId, String critereLibelle, Double critereBareme, Evenement evenement) {
        this.critereId = critereId;
        this.critereLibelle = critereLibelle;
        this.critereBareme = critereBareme;
        this.evenement = evenement;
    }

    public Integer getCritereId() {
        return this.critereId;
    }

    public void setCritereId(Integer critereId) {
        this.critereId = critereId;
    }

    public String getCritereLibelle() {
        return this.critereLibelle;
    }

    public void setCritereLibelle(String critereLibelle) {
        this.critereLibelle = critereLibelle;
    }

    public Double getCritereBareme() {
        return this.critereBareme;
    }

    public void setCritereBareme(Double critereBareme) {
        this.critereBareme = critereBareme;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

}
