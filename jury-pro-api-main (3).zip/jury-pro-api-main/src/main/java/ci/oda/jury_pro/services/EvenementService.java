package ci.oda.jury_pro.services;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.output.EvenementOutput;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.input.EvenementInput;
import ci.oda.jury_pro.repositories.EvenementRepository;

@Service
public class EvenementService {

    @Autowired
    EvenementRepository evenementRepository;

    public List<Evenement> findAll() {
        return evenementRepository.findAll();
    }

    public List<EvenementOutput> findAllTest() {
        return evenementRepository.findWithCountParticipant();
    }

    public Optional<Evenement> findById(Integer id) {
        Optional<Evenement>  even = evenementRepository.findById(id);
        return even;
    }

    public Evenement createOrUpdate(EvenementInput newEvenement){
        byte[] decodedBytes;
        if(newEvenement.getImage64().contains(",")){
            decodedBytes = Base64.getDecoder().decode(newEvenement.getImage64().split(",")[1]);
        }else{
            decodedBytes = Base64.getDecoder().decode(newEvenement.getImage64());
        }
        return evenementRepository.save(new Evenement(newEvenement.getEvenementId(), newEvenement.getEvenementNom(), newEvenement.getEvenementDateDebut(), newEvenement.getEvenementDateFin(), newEvenement.getEvenementType(), decodedBytes));
    }


    public boolean deleteById(Evenement evenement){
        try{
            evenementRepository.deleteById(evenement.getEvenementId());
            return true;
        }catch(IllegalArgumentException e){
            return false;
        }
    }

}
