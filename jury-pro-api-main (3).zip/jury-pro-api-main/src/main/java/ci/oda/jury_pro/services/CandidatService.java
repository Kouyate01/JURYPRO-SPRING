package ci.oda.jury_pro.services;

import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.output.CandidatOutput;
import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.input.CandidatInput;
import ci.oda.jury_pro.repositories.CandidatRepository;
import ci.oda.jury_pro.repositories.EvenementRepository;

@Service
public class CandidatService {
    @Autowired
    CandidatRepository candidatRepository;

    @Autowired
    EvenementRepository evenementRepository;

    public List<Candidat> findAll() {
        return candidatRepository.findAll();
    }

    public Optional<Candidat> findById(Integer id) {
        Optional<Candidat>  candidat = candidatRepository.findById(id);
        return candidat;
    }

    public List<Candidat> findByEvenement(Evenement event){
        return candidatRepository.findByEvenement(event);
    }

    public List<CandidatOutput> findByEvenementTest(Integer eventId) {
        return candidatRepository.findByEvenementWithParticipantCount(eventId);
    }

    public Candidat createOrUpdate(CandidatInput newCandidat){
        byte[] decodedBytes;
        if(newCandidat.getImage64().contains(",")){
            decodedBytes = Base64.getDecoder().decode(newCandidat.getImage64().split(",")[1]);
        }else{
            decodedBytes = Base64.getDecoder().decode(newCandidat.getImage64());
        }
        Candidat candidat = new Candidat(newCandidat.getCandidatId(), null, null, newCandidat.getCandidatNom(), newCandidat.getCandidatPrenoms(), decodedBytes, newCandidat.getCandidatEmail(), newCandidat.getType());
        if(newCandidat.getEvenementId() != null){
            candidat.setEvenement(evenementRepository.findById(newCandidat.getEvenementId()).orElseThrow());
        }
        if(newCandidat.getGroupeId() != null){
            candidat.setGroupe(candidatRepository.findById(newCandidat.getGroupeId()).orElseThrow());
        }
        return candidatRepository.save(candidat);
    }

    public List<Candidat> findChildren(Integer parentId){
        return candidatRepository.findChildren(parentId);
    }

    public boolean deleteById(Candidat candidat){
        // return true;
        try{
            candidatRepository.delete(candidat);
            return true;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
    }

}
