package ci.oda.jury_pro.exceptions;

public class EvenementNotFoundException extends RuntimeException {
    private static final long serialVersionUID = -271843137256374957L;
    public EvenementNotFoundException(Integer id) {
        super("Could not find event " + id);
    }
}
