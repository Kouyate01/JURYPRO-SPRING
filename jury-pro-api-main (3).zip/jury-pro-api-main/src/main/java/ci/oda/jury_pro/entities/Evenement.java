package ci.oda.jury_pro.entities;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "evenements")
public class Evenement {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer evenementId;
    private String evenementNom;
    private Date evenementDateDebut;
    private Date evenementDateFin;
    private boolean evenementType;
    @Lob
    private byte[] evenementImage;

    @OneToMany(mappedBy = "evenement", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<Candidat> candidats;

    @OneToMany(mappedBy = "evenement", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<Jury> jurys;

    @OneToMany(mappedBy = "evenement", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<Critere> criteres;

    public Evenement() {
    }

    public Evenement(Integer evenementId, String evenementNom, Date evenementDateDebut, Date evenementDateFin, boolean evenementType, byte[] evenementImage) {
        this.evenementId = evenementId;
        this.evenementNom = evenementNom;
        this.evenementDateDebut = evenementDateDebut;
        this.evenementDateFin = evenementDateFin;
        this.evenementType = evenementType;
        this.evenementImage = evenementImage;
    }

    public Evenement(String evenementNom, Date evenementDateDebut, Date evenementDateFin, boolean evenementType, byte[] evenementImage) {
        this.evenementNom = evenementNom;
        this.evenementDateDebut = evenementDateDebut;
        this.evenementDateFin = evenementDateFin;
        this.evenementType = evenementType;
        this.evenementImage = evenementImage;
    }


    public Integer getEvenementId() {
        return this.evenementId;
    }

    public String getEvenementNom() {
        return this.evenementNom;
    }

    public Date getEvenementDateDebut() {
        return this.evenementDateDebut;
    }

    public Date getEvenementDateFin() {
        return this.evenementDateFin;
    }

    public boolean getEvenementType() {
        return this.evenementType;
    }

    public boolean isEvenementType() {
        return this.evenementType;
    }


    public byte[] getEvenementImage() {
        return this.evenementImage;
    }

    public void setEvenementImage(byte[] evenementImage) {
        this.evenementImage = evenementImage;
    }


    public void setEvenementId(Integer evenementId) {
        this.evenementId = evenementId;
    }
    public void setEvenementNom(String evenementNom) {
        this.evenementNom = evenementNom;
    }
    public void setEvenementDateDebut(Date evenementDateDebut) {
        this.evenementDateDebut = evenementDateDebut;
    }
    public void setEvenementDateFin(Date evenementDateFin) {
        this.evenementDateFin = evenementDateFin;
    }
    public void setEvenementType(boolean evenementType) {
        this.evenementType = evenementType;
    }

    // public List<Candidat> getCandidats() {
    //     return this.candidats;
    // }

    // public void setCandidats(List<Candidat> candidats) {
    //     this.candidats = candidats;
    // }

}
