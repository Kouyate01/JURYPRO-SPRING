package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ci.oda.jury_pro.entities.Critere;
import ci.oda.jury_pro.entities.Evenement;

public interface CritereRepository extends JpaRepository<Critere, Integer> {
    // List<Critere> findByEvenement(Evenement evenement);

    List<Critere> findByEvenement(Evenement evenement);
}
