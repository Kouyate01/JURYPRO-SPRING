package ci.oda.jury_pro.exceptions;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class EvenementNotFoundAdvice {
    
    @ResponseBody
    @ExceptionHandler(EvenementNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    String evenementNotFoundHandler(EvenementNotFoundException ex) {
      return ex.getMessage();
    }
}
