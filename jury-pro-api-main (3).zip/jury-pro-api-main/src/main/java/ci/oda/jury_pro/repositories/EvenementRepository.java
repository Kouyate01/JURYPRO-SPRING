package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import ci.oda.jury_pro.output.EvenementOutput;
import ci.oda.jury_pro.entities.Evenement;

public interface EvenementRepository extends JpaRepository<Evenement, Integer> {

    @Query(value = "SELECT EV.evenement_id as evenementId, EV.evenement_nom as evenementNom, EV.evenement_date_debut as evenementDateDebut, EV.evenement_date_fin as evenementDateFin, EV.evenement_type as evenementType, EV.evenement_image as evenementImage, coalesce(GP.nombre, 0) as 'nbreParticipant'  FROM evenements as EV LEFT OUTER JOIN ( SELECT CA.evenement_evenement_id, COUNT(*) AS nombre FROM candidats as CA GROUP BY CA.evenement_evenement_id ) AS GP ON (EV.evenement_id = GP.evenement_evenement_id)", nativeQuery = true)
    List<EvenementOutput> findWithCountParticipant();
}
