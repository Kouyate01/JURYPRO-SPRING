package ci.oda.jury_pro.output;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import ci.oda.jury_pro.entities.CritereNotation;
import ci.oda.jury_pro.entities.Jury;

public class VoteOutput {
    private String commentaire;

    private Integer voteId;

    private Jury jury;

    private List<CritereNotation> notations = new ArrayList<CritereNotation>();


    public VoteOutput() {
    }

    public VoteOutput(String commentaire, Integer voteId, Jury jury, List<CritereNotation> notations) {
        this.commentaire = commentaire;
        this.voteId = voteId;
        this.jury = jury;
        this.notations = notations;
    }

    public String getCommentaire() {
        return this.commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Integer getVoteId() {
        return this.voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public Jury getJury() {
        return this.jury;
    }

    public void setJury(Jury jury) {
        this.jury = jury;
    }

    public List<CritereNotation> getNotations() {
        return this.notations;
    }

    public void setNotations(List<CritereNotation> notations) {
        this.notations = notations;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof VoteOutput)) {
            return false;
        }
        VoteOutput voteOutput = (VoteOutput) o;
        return Objects.equals(commentaire, voteOutput.commentaire) && Objects.equals(voteId, voteOutput.voteId) && Objects.equals(jury, voteOutput.jury) && Objects.equals(notations, voteOutput.notations);
    }

    @Override
    public int hashCode() {
        return Objects.hash(commentaire, voteId, jury, notations);
    }

    @Override
    public String toString() {
        return "{" +
            " commentaire='" + getCommentaire() + "'" +
            ", voteId='" + getVoteId() + "'" +
            ", jury='" + getJury() + "'" +
            ", notations='" + getNotations() + "'" +
            "}";
    }

}
