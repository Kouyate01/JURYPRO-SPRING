package ci.oda.jury_pro.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Critere;
import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.repositories.CritereRepository;

@Service
public class CritereService {
    @Autowired
    CritereRepository critereRepository;

    public List<Critere> findAll() {
        return critereRepository.findAll();
    }

    public Optional<Critere> findById(Integer id) {
        Optional<Critere>  even = critereRepository.findById(id);
        return even;
    }

    public List<Critere> findByEvenement(Evenement event){
        return critereRepository.findByEvenement(event);
    }

    public Critere createOrUpdate(Critere critere){
        return critereRepository.save(critere);
    }


    public boolean deleteById(Critere critere){
        try{
            critereRepository.deleteById(critere.getCritereId());
            return true;
        }catch(IllegalArgumentException e){
            return false;
        }
    }
}
