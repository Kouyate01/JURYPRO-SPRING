package ci.oda.jury_pro.input;

import java.util.List;

import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Jury;

public class VoteInput {

    private Integer voteId;

    private Jury voteJury;

    private Candidat voteCandidat;

    private String voteCommentaire;

    private List<NotationInput> voteNotations;


    public VoteInput() {
    }


    public VoteInput(Integer voteId, Jury voteJury, Candidat voteCandidat, String voteCommentaire, List<NotationInput> voteNotations) {
        this.voteId = voteId;
        this.voteJury = voteJury;
        this.voteCandidat = voteCandidat;
        this.voteCommentaire = voteCommentaire;
        this.voteNotations = voteNotations;
    }



    public Integer getVoteId() {
        return this.voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }


    public String getVoteCommentaire() {
        return this.voteCommentaire;
    }

    public void setVoteCommentaire(String voteCommentaire) {
        this.voteCommentaire = voteCommentaire;
    }


    public Jury getVoteJury() {
        return this.voteJury;
    }

    public void setVoteJury(Jury voteJury) {
        this.voteJury = voteJury;
    }

    public Candidat getVoteCandidat() {
        return this.voteCandidat;
    }

    public void setVoteCandidat(Candidat voteCandidat) {
        this.voteCandidat = voteCandidat;
    }


    public List<NotationInput> getVoteNotations() {
        return this.voteNotations;
    }

    public void setVoteNotations(List<NotationInput> voteNotations) {
        this.voteNotations = voteNotations;
    }

}
