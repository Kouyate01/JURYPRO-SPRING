package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Vote;

public interface VoteRepository extends JpaRepository<Vote, Integer> {
    List<Vote> findByVoteCandidat(Candidat voteCandidat);
}
