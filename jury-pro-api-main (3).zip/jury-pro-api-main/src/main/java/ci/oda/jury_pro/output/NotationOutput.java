package ci.oda.jury_pro.output;

import ci.oda.jury_pro.entities.Critere;

public class NotationOutput {
    private Critere critere;

    private Double note;


    public NotationOutput() {
    }

    public NotationOutput(Critere critere, Double note) {
        this.critere = critere;
        this.note = note;
    }

    public Critere getCritere() {
        return this.critere;
    }

    public void setCritere(Critere critere) {
        this.critere = critere;
    }

    public Double getNote() {
        return this.note;
    }

    public void setNote(Double note) {
        this.note = note;
    }

}
