package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ci.oda.jury_pro.entities.Candidat;
import ci.oda.jury_pro.entities.Vote;
import ci.oda.jury_pro.exceptions.EvenementNotFoundException;
import ci.oda.jury_pro.input.VoteInput;
import ci.oda.jury_pro.output.NotationOutput;
import ci.oda.jury_pro.output.VoteOutput;
import ci.oda.jury_pro.services.CandidatService;
import ci.oda.jury_pro.services.VoteService;

@RestController
@CrossOrigin
public class VoteController {
    @Autowired
    VoteService voteService;

    @Autowired
    CandidatService  candidatService;

    @GetMapping("/vote")
    public List<Vote> all() {
        return voteService.findAll();
    }

    @GetMapping("/vote/{id}")
    Vote one(@PathVariable Integer id) {
        return voteService.findById(id).orElseThrow(() -> new EvenementNotFoundException(id));
    }

    @GetMapping("/vote/candidat/{candidatId}")
    List<VoteOutput> findByCandidat(@PathVariable Integer candidatId){
        return this.candidatService.findById(candidatId).map((Candidat candidat) -> {
            return this.voteService.findByCandidat(candidat);
        }).orElseThrow(() -> new EvenementNotFoundException(candidatId));
    }

    @PostMapping("/vote")
    public Boolean create(@RequestBody VoteInput votes) {
        return voteService.createOrUpdate(votes);
    }

    @DeleteMapping("/vote/{id}")
    public Boolean delete(@PathVariable Integer id){
        return voteService.findById(id)
            .map((Vote vote) -> {
                return voteService.deleteById(vote);
            }).orElse(false);
    }
}
