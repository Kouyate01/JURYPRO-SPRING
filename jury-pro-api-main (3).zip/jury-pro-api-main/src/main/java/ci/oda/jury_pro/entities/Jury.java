package ci.oda.jury_pro.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "jurys")
public class Jury {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer juryId;
    private String juryNomComplet;
    private String juryTelephone;
    private String juryEmail;

    @ManyToOne
    private Evenement evenement;

    @OneToMany(mappedBy = "voteJury", cascade = CascadeType.REMOVE)
    @JsonIgnore
    private List<Vote> votes;


    public Jury() {
    }

    public Jury(Integer juryId, String juryNomComplet, String juryTelephone, String juryEmail, Evenement evenement) {
        this.juryId = juryId;
        this.juryNomComplet = juryNomComplet;
        this.juryTelephone = juryTelephone;
        this.juryEmail = juryEmail;
        this.evenement = evenement;
    }

    public Integer getJuryId() {
        return this.juryId;
    }

    public void setJuryId(Integer juryId) {
        this.juryId = juryId;
    }

    public String getJuryNomComplet() {
        return this.juryNomComplet;
    }

    public void setJuryNomComplet(String juryNomComplet) {
        this.juryNomComplet = juryNomComplet;
    }

    public String getJuryTelephone() {
        return this.juryTelephone;
    }

    public void setJuryTelephone(String juryTelephone) {
        this.juryTelephone = juryTelephone;
    }

    public String getJuryEmail() {
        return this.juryEmail;
    }

    public void setJuryEmail(String juryEmail) {
        this.juryEmail = juryEmail;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

    @Override
    public String toString() {
        return "{" +
            " juryId='" + getJuryId() + "'" +
            ", juryNomComplet='" + getJuryNomComplet() + "'" +
            ", juryTelephone='" + getJuryTelephone() + "'" +
            ", juryEmail='" + getJuryEmail() + "'" +
            ", evenement='" + getEvenement() + "'" +
            "}";
    }

}
