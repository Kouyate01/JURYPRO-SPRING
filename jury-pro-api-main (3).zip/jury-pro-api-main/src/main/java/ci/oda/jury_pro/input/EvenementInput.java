package ci.oda.jury_pro.input;

import java.sql.Date;

public class EvenementInput {
    private Integer evenementId;
    private String evenementNom;
    private Date evenementDateDebut;
    private Date evenementDateFin;
    private boolean evenementType;
    private String image64;


    public EvenementInput() {
    }

    public EvenementInput(Integer evenementId, String evenementNom, Date evenementDateDebut, Date evenementDateFin, boolean evenementType, String image64) {
        this.evenementId = evenementId;
        this.evenementNom = evenementNom;
        this.evenementDateDebut = evenementDateDebut;
        this.evenementDateFin = evenementDateFin;
        this.evenementType = evenementType;
        this.image64 = image64;
    }

    public Integer getEvenementId() {
        return this.evenementId;
    }

    public void setEvenementId(Integer evenementId) {
        this.evenementId = evenementId;
    }

    public String getEvenementNom() {
        return this.evenementNom;
    }

    public void setEvenementNom(String evenementNom) {
        this.evenementNom = evenementNom;
    }

    public Date getEvenementDateDebut() {
        return this.evenementDateDebut;
    }

    public void setEvenementDateDebut(Date evenementDateDebut) {
        this.evenementDateDebut = evenementDateDebut;
    }

    public Date getEvenementDateFin() {
        return this.evenementDateFin;
    }

    public void setEvenementDateFin(Date evenementDateFin) {
        this.evenementDateFin = evenementDateFin;
    }

    public boolean isEvenementType() {
        return this.evenementType;
    }

    public boolean getEvenementType() {
        return this.evenementType;
    }

    public void setEvenementType(boolean evenementType) {
        this.evenementType = evenementType;
    }

    public String getImage64() {
        return this.image64;
    }

    public void setImage64(String image64) {
        this.image64 = image64;
    }

}