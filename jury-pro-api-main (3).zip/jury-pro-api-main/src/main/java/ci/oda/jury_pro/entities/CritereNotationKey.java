package ci.oda.jury_pro.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CritereNotationKey implements Serializable{

    @Column(name = "vote_id")
    Integer voteId;

    @Column(name = "critere_id")
    Integer critereId;


    public CritereNotationKey() {
    }

    public CritereNotationKey(Integer voteId, Integer critereId) {
        this.voteId = voteId;
        this.critereId = critereId;
    }



    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof CritereNotationKey)) {
            return false;
        }
        CritereNotationKey critereNotation = (CritereNotationKey) o;
        return Objects.equals(voteId, critereNotation.voteId) && Objects.equals(critereId, critereNotation.critereId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(voteId, critereId);
    }

}
