package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.entities.Jury;

public interface JuryRepository extends JpaRepository<Jury, Integer> {
    List<Jury> findByEvenement(Evenement evenement);

    List<Jury> findByJuryTelephone(String juryTelephone);
}
