package ci.oda.jury_pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuryProApplicationTests {

	@Test
	void contextLoads() {
	}

}
